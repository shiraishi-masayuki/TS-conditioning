/* nav.js v2 — TS conditioning | responsive + a11y */
(function () {
  var header    = document.getElementById('site-header');
  var hamburger = document.getElementById('hamburger');
  var mobileNav = document.getElementById('mobile-nav');

  /* ── ヘッダー スクロール連動 ── */
  function updateHeader() {
    if (!header) return;
    var isLight = header.dataset.light === 'true';
    if (window.scrollY > 60) {
      header.classList.remove('transparent', 'light-bg');
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
      header.classList.add(isLight ? 'light-bg' : 'transparent');
    }
  }
  window.addEventListener('scroll', updateHeader, { passive: true });
  updateHeader();

  /* ── ハンバーガー / モバイルナビ ── */
  function openMenu() {
    mobileNav.classList.add('open');
    hamburger.classList.add('open');
    hamburger.setAttribute('aria-expanded', 'true');
    mobileNav.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
  function closeMenu() {
    mobileNav.classList.remove('open');
    hamburger.classList.remove('open');
    hamburger.setAttribute('aria-expanded', 'false');
    mobileNav.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', function () {
      mobileNav.classList.contains('open') ? closeMenu() : openMenu();
    });

    /* モバイルナビ内リンクをタップで閉じる */
    mobileNav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', closeMenu);
    });

    /* Escキーで閉じる */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mobileNav.classList.contains('open')) closeMenu();
    });
  }

  /* ── アクティブリンク ── */
  var current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link, .mobile-nav-link').forEach(function (a) {
    if (a.getAttribute('href') === current) a.classList.add('active');
  });

  /* ── スクロールフェードイン ── */
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -32px 0px' });
    document.querySelectorAll('.fade-up').forEach(function (el) { io.observe(el); });
  } else {
    /* フォールバック：古いブラウザ */
    document.querySelectorAll('.fade-up').forEach(function (el) {
      el.classList.add('visible');
    });
  }

  /* ── FAQ アコーディオン ── */
  document.querySelectorAll('.faq-item').forEach(function (item) {
    var q = item.querySelector('.faq-q');
    var a = item.querySelector('.faq-a');
    if (!q || !a) return;

    /* アクセシビリティ属性 */
    var id = 'faq-a-' + Math.random().toString(36).slice(2, 7);
    a.id = id;
    q.setAttribute('role', 'button');
    q.setAttribute('tabindex', '0');
    q.setAttribute('aria-expanded', 'false');
    q.setAttribute('aria-controls', id);

    function toggle() {
      var open = item.classList.toggle('open');
      a.style.maxHeight = open ? a.scrollHeight + 'px' : '0';
      q.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    q.addEventListener('click', toggle);
    q.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });
  });
})();
